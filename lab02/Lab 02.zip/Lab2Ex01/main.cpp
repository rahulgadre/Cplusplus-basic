//**************************************************************************
//*** PROGRAM:             Lab2Ex01                                      ***
//***                                                                    ***
//*** PURPOSE:             Laboratory Exercise 2 for ISTE100             ***
//***                                                                    ***
//*** WRITTEN BY:          Alec Berenbaum                                ***
//***                                                                    ***
//*** DESCRIPTION:         This program is used to illustrate the use of ***
//***                      namespaces.                                   ***
//**************************************************************************
#include <iostream>
#include <string>



//**************************************************************************
//*** MAIN FUNCTION                                                      ***
//**************************************************************************

int main()
{
    //***
    //*** Declaration of variables
    //***
    string sFirstName;                      // First Name
    char   cMiddleInitial;                  // Middle initial
    string sLastName;                       // Last Name

    //***
    //*** Prompt the user for his/her name in components.
    //***
    cout << "Please enter your FIRST NAME:     ";
    getline(cin, sFirstName);

    cout << "Please enter your MIDDLE INITIAL: ";
    cin  >> cMiddleInitial;
    cin.ignore(1000, '\n');

    cout << "Please enter your LAST NAME:      ";
    getline(cin, sLastName);

    //***
    //*** Output the Formal Name.
    //***
    cout << endl << "Your FORMAL NAME is:              " << sLastName << ", "
         << sFirstName << "  " << cMiddleInitial << "."  << endl << endl;

    //***
    //*** PAUSE PROGRAM
    //***
    cout << "Press <ENTER> to exit...";
    cin.ignore(1000, '\n');


    return 0;
}
