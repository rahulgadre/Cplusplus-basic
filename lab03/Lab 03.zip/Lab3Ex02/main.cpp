//**************************************************************************
//*** PROGRAM:             Lab3Ex02                                      ***
//***                                                                    ***
//*** PURPOSE:             Laboratory Exercise 3 for ISTE100             ***
//***                                                                    ***
//*** WRITTEN BY:          Alec Berenbaum                                ***
//***                                                                    ***
//*** DESCRIPTION:         This program illustrates the use of functions ***
//***                      to perform mathematical operations.  The      ***
//***                      functions come from the <cmath> library.      ***
//***                      This exercise also introduces student to      ***
//***                      selection.                                    ***
//**************************************************************************
#include <iostream>

using namespace std;

int main()
{
    double dfLeg1, dfLeg2, dfHypotenuse;               // Declaration of legs and hypotenuse

    //***
    //*** Prompt the user for leg 1.
    //***



    //***
    //*** Prompt the user for Hypotenuse.
    //***


    //**********************************************************************
    //*** At this point we know that inputs are valid - OK to calculate. ***
    //**********************************************************************


    //***
    //*** Get square of hypotenuse and leg 1.
    //***


    //***
    //*** Calculate square of leg 2, then calculate leg 2
    //***


    //***
    //*** Output the results.
    //***
    cout << endl << "The length of leg 2 of the triangle is " << dfLeg2 << endl;

    cout << endl << "Press <ENTER> to exit....";
    cin.ignore(1000, '\n');


    return 0;

}
