//**************************************************************************
//*** PROGRAM:             Lab3Ex03                                      ***
//***                                                                    ***
//*** PURPOSE:             Laboratory Exercise 3 for ISTE100             ***
//***                                                                    ***
//*** WRITTEN BY:          Alec Berenbaum                                ***
//***                                                                    ***
//*** DESCRIPTION:         This program illustrates the use of functions ***
//***                      to perform mathematical operations.  The      ***
//***                      functions come from the <cmath> library.      ***
//***                      This exercise also introduces student to      ***
//***                      selection.                                    ***
//**************************************************************************
#include <iostream>


using namespace std;

    // Constant to define PI

int main()
{

    double dfSideA, dfSideB, dfSideC;
    double dfAngleC;

    //***
    //*** Prompt the user for known sides, A and B
    //***



    //***
    //*** Prompt the user for known angle C
    //***


    //***
    //*** Calculate the square of the side C
    //***


    //***
    //*** Calculate the side C
    //***


    //***
    //*** Output the results.
    //***
    cout << endl << "The Side C of the triangle is " << dfSideC << endl;

    cout << endl << "Press <ENTER> to exit....";
    cin.ignore(1000, '\n');

    return 0;
}
