#include <iostream>

using namespace std;

int main()
{
    int x;
    int y;


    cout << "x resides at " << &x << endl;
    cout << "y resides at " << &y << endl;

    return 0;
}
